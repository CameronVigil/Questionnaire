var quizQuestions = [
  {
    question: "What is your year classification?",
    answers: [
      {
        type: "Group 1",
        content: "Freshman"
      },
      {
        type: "Group 1",
        content: "Sophomore"
      },
      {
        type: "Group 3",
        content: "Junior"
      },
      {
        type: "Group 4",
        content: "Senior and up"
      }
    ]
  },
  {
    question: "What would you prefer to do with friends?",
    answers: [
      {
        type: "Group 1",
        content: "Play video games"
      },
      {
        type: "Group 2",
        content: "Hang out on campus"
      },
      {
        type: "Group 3",
        content: "Go to someone's place and hang out"
      },
      {
        type: "Group 4",
        content: "Stay in and watch Netflix"
      }
    ]
  },
  {
    question: "What school?",
    answers: [
      {
        type: "Group 1",
        content: "Freshman"
      },
      {
        type: "Group 2",
        content: "Sophomore"
      },
      {
        type: "Group 3",
        content: "Junior"
      },
      {
        type: "Group 4",
        content: "Senior"
      }
    ]
  },
  {
    question: "What is your year classification?",
    answers: [
      {
        type: "Group 1",
        content: "Freshman"
      },
      {
        type: "Group 2",
        content: "Sophomore"
      },
      {
        type: "Group 3",
        content: "Junior"
      },
      {
        type: "Group 4",
        content: "Senior"
      }
    ]
  },
  {
    question: "What is your year classification?",
    answers: [
      {
        type: "Group 1",
        content: "Freshman"
      },
      {
        type: "Group 2",
        content: "Sophomore"
      },
      {
        type: "Group 3",
        content: "Junior"
      },
      {
        type: "Group 4",
        content: "Senior"
      }
    ]
  }
];

export default quizQuestions;
